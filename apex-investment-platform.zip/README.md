# Apex Investment Channel — production-oriented starter

## Included
- Full dashboard/navigation: dashboard, invest, deposit, withdraw/redeem request, portfolio, transactions, markets, security, support/legal.
- Live cryptocurrency market prices and charts through CoinGecko API.
- Paystack hosted checkout + server-side verification + signed webhook.
- BTCPay Server Bitcoin invoice creation + signed webhook status tracking.
- Your supplied BTC receiving address in `.env`.
- SQLite payment/withdrawal/invoice records.
- Server-side secret handling.

## Important production boundary
This code intentionally does NOT fabricate investment balances, profits, licenses, customer deposits, or completed withdrawals. Portfolio balances must come from a real authorized custodian/ledger. Withdrawal requests are recorded but not silently paid out.

Before accepting public investment funds in Nigeria, verify the business/operator and scope of authorization with the SEC. The SEC states that entities promoting investment services, providing investment advisory services, or soliciting funds from the public in the Nigerian capital market must be registered.

## Install
1. Node.js 20+
2. `npm install`
3. Copy `.env.example` to `.env`
4. Fill in live Paystack and BTCPay credentials.
5. Set `BASE_URL` to your HTTPS domain.
6. Configure Paystack webhook: `/webhooks/paystack`
7. Configure BTCPay webhook: `/webhooks/btcpay`
8. `npm start`

Never commit `.env`, API keys, private keys or seed phrases.

## Currency-to-BTC
Paystack checkout handles supported fiat payments. BTCPay handles Bitcoin invoices. A fiat-to-BTC conversion layer is NOT included because it requires a compliant exchange/settlement provider and jurisdiction/account approval. Connect that provider server-side if your business is authorized to do so.
