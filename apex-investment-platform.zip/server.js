
import express from "express";
import helmet from "helmet";
import morgan from "morgan";
import dotenv from "dotenv";
import crypto from "crypto";
import Database from "better-sqlite3";
dotenv.config();

const app=express(), db=new Database("apex.sqlite");
const PORT=process.env.PORT||3000;
app.use(helmet({contentSecurityPolicy:false}));
app.use(morgan("tiny"));
app.use(express.json({verify:(req,res,buf)=>req.rawBody=buf}));
app.use(express.static("public"));

db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,reference TEXT UNIQUE,provider TEXT,email TEXT,amount INTEGER,currency TEXT,status TEXT,provider_id TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS btc_invoices(id INTEGER PRIMARY KEY,order_id TEXT UNIQUE,invoice_id TEXT UNIQUE,status TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY,user_email TEXT,method TEXT,destination TEXT,amount REAL,currency TEXT,status TEXT DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

function env(...keys){for(const k of keys)if(!process.env[k])throw Error("Missing "+k)}
async function paystack(path,opts={}){
 env("PAYSTACK_SECRET_KEY");
 const r=await fetch("https://api.paystack.co"+path,{...opts,headers:{Authorization:"Bearer "+process.env.PAYSTACK_SECRET_KEY,"Content-Type":"application/json",...(opts.headers||{})}});
 const d=await r.json(); if(!r.ok||!d.status)throw Error(d.message||"Paystack error"); return d;
}
async function btcpay(path,opts={}){
 env("BTCPAY_URL","BTCPAY_STORE_ID","BTCPAY_API_KEY");
 const r=await fetch(process.env.BTCPAY_URL+"/api/v1"+path,{...opts,headers:{Authorization:"token "+process.env.BTCPAY_API_KEY,"Content-Type":"application/json",...(opts.headers||{})}});
 const t=await r.text();let d={};try{d=JSON.parse(t)}catch{} if(!r.ok)throw Error(d.message||t);return d;
}

/* LIVE MARKET DATA: CoinGecko. These are market prices, not fabricated account balances. */
app.get("/api/market",async(req,res)=>{
 try{
  const ids="bitcoin,ethereum,tether,binancecoin,solana,usd-coin,ripple,cardano";
  const q=new URLSearchParams({ids,vs_currencies:"usd",include_24hr_change:"true",include_market_cap:"true"});
  const headers={};if(process.env.COINGECKO_API_KEY)headers["x-cg-demo-api-key"]=process.env.COINGECKO_API_KEY;
  const r=await fetch("https://api.coingecko.com/api/v3/simple/price?"+q,{headers});
  if(!r.ok)throw Error("Market API unavailable");res.json(await r.json());
 }catch(e){res.status(503).json({error:e.message})}
});

app.get("/api/market-chart/:coin",async(req,res)=>{
 try{
  const q=new URLSearchParams({vs_currency:"usd",days:req.query.days||"1",interval:"hourly"});
  const headers={};if(process.env.COINGECKO_API_KEY)headers["x-cg-demo-api-key"]=process.env.COINGECKO_API_KEY;
  const r=await fetch(`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(req.params.coin)}/market_chart?${q}`,{headers});
  if(!r.ok)throw Error("Chart API unavailable");res.json(await r.json());
 }catch(e){res.status(503).json({error:e.message})}
});

/* REAL FIAT CHECKOUT: Paystack hosted checkout + server verification. */
app.post("/api/payments/paystack",async(req,res)=>{
 try{
  const {email,amount,currency="USD"}=req.body;
  if(!email||!Number(amount)||Number(amount)<=0)return res.status(400).json({error:"Invalid payment"});
  const c=String(currency).toUpperCase(); if(!["USD","NGN"].includes(c))return res.status(400).json({error:"Currency not enabled in this starter"});
  const reference="APX-"+Date.now()+"-"+crypto.randomBytes(4).toString("hex");
  db.prepare("INSERT INTO payments(reference,provider,email,amount,currency,status) VALUES(?,?,?,?,?,?)").run(reference,"paystack",email,Math.round(Number(amount)*100),c,"initialized");
  const d=await paystack("/transaction/initialize",{method:"POST",body:JSON.stringify({email,amount:Math.round(Number(amount)*100),currency:c,reference,callback_url:process.env.BASE_URL+"/?payment=return"})});
  res.json({url:d.data.authorization_url,reference});
 }catch(e){res.status(500).json({error:e.message})}
});
app.get("/api/payments/paystack/:reference",async(req,res)=>{
 try{
  const d=await paystack("/transaction/verify/"+encodeURIComponent(req.params.reference));
  db.prepare("UPDATE payments SET status=?,provider_id=? WHERE reference=?").run(d.data.status==="success"?"paid":d.data.status,String(d.data.id||""),req.params.reference);
  res.json({status:d.data.status,amount:d.data.amount,currency:d.data.currency,reference:req.params.reference});
 }catch(e){res.status(500).json({error:e.message})}
});
app.post("/webhooks/paystack",async(req,res)=>{
 try{
  const sig=req.headers["x-paystack-signature"], exp=crypto.createHmac("sha512",process.env.PAYSTACK_SECRET_KEY).update(req.rawBody).digest("hex");
  if(!sig||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(exp)))return res.sendStatus(401);
  if(req.body.event==="charge.success"&&req.body.data?.reference){
   const d=await paystack("/transaction/verify/"+encodeURIComponent(req.body.data.reference));
   if(d.data.status==="success")db.prepare("UPDATE payments SET status='paid',provider_id=? WHERE reference=?").run(String(d.data.id),req.body.data.reference);
  }res.sendStatus(200);
 }catch(e){res.sendStatus(500)}
});

/* REAL BTC INVOICE CREATION through BTCPay. */
app.post("/api/payments/btc",async(req,res)=>{
 try{
  const {email,amount}=req.body;if(!email||!Number(amount)||Number(amount)<=0)return res.status(400).json({error:"Invalid payment"});
  const orderId="APX-BTC-"+Date.now()+"-"+crypto.randomBytes(3).toString("hex");
  const d=await btcpay(`/stores/${process.env.BTCPAY_STORE_ID}/invoices`,{method:"POST",body:JSON.stringify({amount:Number(amount),currency:"USD",orderId,itemDesc:"Apex checkout"})});
  db.prepare("INSERT INTO btc_invoices(order_id,invoice_id,status) VALUES(?,?,?)").run(orderId,d.id,"New");
  res.json({invoiceId:d.id,checkoutLink:d.checkoutLink,orderId});
 }catch(e){res.status(500).json({error:e.message})}
});
app.post("/webhooks/btcpay",(req,res)=>{
 try{
  const s=process.env.BTCPAY_WEBHOOK_SECRET,sig=req.headers["btcpay-sig"];
  if(!s)return res.sendStatus(503);
  const exp="sha256="+crypto.createHmac("sha256",s).update(req.rawBody).digest("hex");
  if(!sig||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(exp)))return res.sendStatus(401);
  const map={InvoiceProcessing:"Processing",InvoiceSettled:"Settled",InvoiceInvalid:"Invalid",InvoiceExpired:"Expired",InvoicePaymentSettled:"Settled"};
  if(req.body.invoiceId&&map[req.body.type])db.prepare("UPDATE btc_invoices SET status=? WHERE invoice_id=?").run(map[req.body.type],req.body.invoiceId);
  res.sendStatus(200);
 }catch(e){res.sendStatus(500)}
});

app.get("/api/config",(req,res)=>res.json({btc:process.env.BTC_RECEIVING_ADDRESS||"",btcEnabled:!!process.env.BTCPAY_URL}));
app.post("/api/withdrawal-request",async(req,res)=>{
 /* Creates a withdrawal request for review. Actual investment-fund payout must use your
    authorized custodian/provider and documented controls; this endpoint intentionally
    does not silently move customer funds. */
 const {email,method,destination,amount,currency}=req.body;
 if(!email||!destination||!Number(amount)||amount<=0)return res.status(400).json({error:"Invalid withdrawal request"});
 const r=db.prepare("INSERT INTO withdrawals(user_email,method,destination,amount,currency) VALUES(?,?,?,?,?)").run(email,method,destination,amount,currency||"USD");
 res.json({id:r.lastInsertRowid,status:"pending"});
});
app.get("/api/health",(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log("Apex running on "+PORT));
